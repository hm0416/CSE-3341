def initialize():
    global isFunc #determines if a function has been declared
    isFunc = False
